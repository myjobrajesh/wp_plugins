/* Social Share Buttons With Floating Sidebar admin js*/
jQuery(document).ready(function(){

	/* add image upload image button */
	jQuery(".smbUploadBtn").click(function() {
		var tdbuttonid = jQuery(this).parent("td").attr("id");
		inputfieldId = jQuery("#"+tdbuttonid+" .inputButtonid").attr("id");
		formfield = jQuery("#"+inputfieldId).attr("name");
		tb_show( "", "media-upload.php?type=image&amp;TB_iframe=true" );
		return false;
	});
	window.send_to_editor = function(html) {
		imgurl = jQuery(html).attr("src");
		jQuery("#"+inputfieldId).val(imgurl);
		tb_remove();
   }
   
/** reset floating sidebar settings  */
   jQuery('#div-smb-sidebar #smb_resetpage').click(function(){
	   jQuery('#div-smb-sidebar .inputButtonid').val('');
	   jQuery('#div-smb-sidebar .smb_title').val('');
	   jQuery('#div-smb-sidebar .color-field').val('');
	   })
	   
   });

(function( ) {
 
    // Add Color Picker to all inputs that have 'color-field' class
    jQuery(function() {
        jQuery('.color-field').wpColorPicker();
    });
     
})( jQuery );
