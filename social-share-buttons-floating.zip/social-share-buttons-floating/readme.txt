=== Social Share Buttons with Floating bar ===
Contributors:Rajesh
Tags: social share buttons,facebook, twitter, linkedin, floating sidebar, floating share buttons
Requires at least: 4.0
Tested up to: 4.9.1
Stable tag: 1.0

Social Share Buttons (Facebook,Twitter,Linkedin) & Floating Sidebar.

== Description ==

= “social-share-buttons-floating” = This is a plugin to share your site among your friends through social sites.

By using this plugin, visitors can share your website on popular social networks such as Facebook, Twitter, Linkedin.

With this plugin, you can give users a tool to share your content, product details and other information with their own networks.

Let users share via their accounts on popular social networks. Install this free plugin to enable Social Sharing on your WordPress site and start driving high quality results to your website.

It is a lightweight plugin. There is no external JS file added  in this plugin so it will not affect your site speed.

You can add social share floating buttons with social share buttons and you can change the share buttons images, size and their style from admin.

= Features =

 * An option to add custom Image of social button.
 * An options to add background color of social button.
 * Responsive Floating Sidebar
 * Share Buttons to every post/page
 * Show/Hide options for any buttons
 * An options to set the position of Floating Sidebar (Left/Right/Bottom)
 * An options to manage the style of the plugin
 * An option to disable sidebar for mobile

For any query contact to **[plugin author](mailto:myjob.rajesh@gmail.com)**

== Installation ==

Step 1.Download the plugin and upload "social-share-buttons-floating" plugins file to plugin (`/wp-content/plugins/`) directory

Step 2. Activate the plugin through the Plugins menu in WordPress

Step 3. Go to Settings/"Social Share Buttons with Floating Sidebar" and configure the plugin settings.

== Frequently Asked Questions ==
1.) How to add floating share buttons on my website?

 * After active the plugin you have must need to enable this plugin through the plugin settings.

2.) Can I change the Social Share buttons images from admin?

 * Yes,From plugin settings page, admin can change all social share buttons images.

3.) Can I disable the floating sidebar for mobile?

 * Yes, from plugin settings page, admin can disable.

4.) Can I define the top margin for share buttons block?

 * Yes, admin can define the top margin from plugin settings page

== Screenshots ==

1. screenshot_admin.png

2. screenshot_detail_bottom.png

3. screenshot-left.png

4. screenshot-list_bottom.png

5. screenshot-right.png

== Changelog == 

= 1.0 =
 * Tested with latest wordpress version 4.9.1
 * Optimized CSS of share buttons
 * First stable release