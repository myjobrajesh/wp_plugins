 <div style="width: 80%; padding: 10px; margin: 10px;"> 

	<h1>Social Share Buttons With Floating buttons Settings</h1>

	<form action="options.php" method="post" id="smb-sidebar-admin-form">

	<p align="right"><span class="submit-btn"><?php echo get_submit_button('Save Settings','button-primary extrabtn','submit','','');?></span></p>
	<div class="smb-setting">
	<!-- General Setting -->	
	<div class="first smb-row" id="div-smb-general">
	    <h2>General Settings</h2>
        <p><input type="checkbox" id="smb_active" name="smb_active" value='1' <?php checked(get_option('smb_active'),1);?>/> <b><?php _e('Enable Sidebar');?> </b></p>

	    <p><h3><strong><?php _e('Social Share Button Publish Options:','smb');?></strong></h3></p>
	    <p><input type="checkbox" id="publish1" value="yes" name="smb_fpublishBtn" <?php checked(get_option('smb_fpublishBtn'),'yes');?>/> <b>Facebook Button</b></p>
				<p><input type="checkbox" id="publish2" name="smb_tpublishBtn" value="yes" <?php checked(get_option('smb_tpublishBtn'),'yes');?>/> <b>Twitter Button</b></p>
				<p><input type="checkbox" id="publish4" name="smb_lpublishBtn" value="yes" <?php checked(get_option('smb_lpublishBtn'),'yes');?>/> <b>Linkedin Button</b></p>
	</div>
	<!-- Floating Sidebar -->
	<div class="smb-row" id="div-smb-sidebar">
	    <h2>Floating Sidebar Settings</h2>
	    <table>
			<tr>
				<th nowrap><?php echo 'Siderbar Position:';?></th>
				<td>
				<select id="smb_position" name="smb_position" >
				<option value="left" <?php selected(get_option('smb_position'),'left');?>>Left</option>
				<option value="right" <?php selected(get_option('smb_position'),'right');?>>Right</option>
				<option value="bottom" <?php selected(get_option('smb_position'),'bottom');?>>Bottom</option>
				</select>
				</td>
			</tr>
            <tr>
				<th>&nbsp;</th>
				<td><input type="checkbox" id="smb_deactive_for_mob" name="smb_deactive_for_mob" value="yes" <?php checked(get_option('smb_deactive_for_mob'),'yes');?>/><?php _e('Disable Sidebar For Mobile','smb');?></td>
			</tr>

			<tr><th>&nbsp;</th><td><input type="checkbox" id="smb_hide_home" value="yes" name="smb_hide_home" <?php checked(get_option('smb_hide_home'),'yes');?>/>Hide Sidebar On Home Page</td></tr>
			<tr><td colspan="2"><strong><h4>Social Share Button Images 35X35 (Optional) :</h4></strong></td></tr>

			<tr>
			<th><?php echo 'Facebook:';?></th>
			<td class="smbButtonsImg" id="smbButtonsFbImg">
	            <input type="text" id="smb_fb_image" name="smb_fb_image" value="<?php echo get_option('smb_fb_image'); ?>" placeholder="Insert facebook button image path" size="30" class="inputButtonid"/>
                <input id="smb_fb_image_button" type="button" value="Upload Image" class="smbUploadBtn"/>&nbsp;&nbsp;
                <input type="text" id="smb_fb_bg" data-default-color="#305891" class="color-field" name="smb_fb_bg" value="<?php echo get_option('smb_fb_bg'); ?>" size="20"/>&nbsp;&nbsp;
                <br>
                <input type="text" id="smb_fb_title"  name="smb_fb_title" value="<?php echo get_option('smb_fb_title'); ?>" placeholder="Share on facebook" size="20" class="smb_title"/>
                <input type="text" id="smb_fb_size_w"  name="smb_fb_size_w" value="<?php echo get_option('smb_fb_size_w'); ?>" placeholder="Width (px)" size="6" class="smb_title"/>
                <input type="text" id="smb_fb_size_h"  name="smb_fb_size_h" value="<?php echo get_option('smb_fb_size_h'); ?>" placeholder="Height (px)" size="7" class="smb_title"/>

            </td>
			</tr>
			<tr><th><?php echo 'Twitter:';?></th>
				<td class="smbButtonsImg" id="smbButtonsTwImg">
				<input type="text" id="smb_tw_image" name="smb_tw_image" value="<?php echo get_option('smb_tw_image'); ?>" placeholder="Insert twitter button image path" size="30" class="inputButtonid"/><input id="smb_tw_image_button" type="button" value="Upload Image" class="smbUploadBtn"/>&nbsp;&nbsp;<input type="text" id="smb_tw_bg" name="smb_tw_bg" value="<?php echo get_option('smb_tw_bg'); ?>" data-default-color="#2ca8d2" class="color-field"  size="20"/>&nbsp;&nbsp;
                    <br>
                    <input type="text" id="smb_tw_title"  name="smb_tw_title" value="<?php echo get_option('smb_tw_title'); ?>" placeholder="Share on twitter" size="20" class="smb_title"/>
                    <input type="text" id="smb_tw_size_w"  name="smb_tw_size_w" value="<?php echo get_option('smb_tw_size_w'); ?>" placeholder="Width (px)" size="6" class="smb_title"/>
                    <input type="text" id="smb_tw_size_h"  name="smb_tw_size_h" value="<?php echo get_option('smb_tw_size_h'); ?>" placeholder="Height (px)" size="7" class="smb_title"/>

                </td>
			</tr>
			<tr>
				<th><?php echo 'Linkedin:';?></th>
				<td class="smbButtonsImg" id="smbButtonsLiImg">
				<input type="text" id="smb_li_image" name="smb_li_image" value="<?php echo get_option('smb_li_image'); ?>" placeholder="Insert Linkedin button image path" class="inputButtonid" size="30" class="buttonimg"/><input id="smb_li_image_button" type="button" value="Upload Image" class="smbUploadBtn"/>&nbsp;&nbsp;<input type="text" id="smb_li_bg" name="smb_li_bg" value="<?php echo get_option('smb_li_bg'); ?>" data-default-color="#dd4c39" class="color-field"  size="20"/>&nbsp;&nbsp;
                    <br><input type="text" id="smb_li_title"  name="smb_li_title" value="<?php echo get_option('smb_li_title'); ?>" placeholder="Share on Linkedin" size="20" class="smb_title"/>
                    <input type="text" id="smb_li_size_w"  name="smb_li_size_w" value="<?php echo get_option('smb_li_size_w'); ?>" placeholder="Width (px)" size="6" class="smb_title"/>
                    <input type="text" id="smb_li_size_h"  name="smb_li_size_h" value="<?php echo get_option('smb_li_size_h'); ?>" placeholder="Height (px)" size="7" class="smb_title"/>

                </td>
			</tr>
            <tr><td colspan="2" align="right"><input type="button" id="smb_resetpage" value="Reset"></td></tr>
			<tr><td colspan="2"><h3><strong>Style(Optional):</strong></h3></td></tr>
			
			<tr>
				<th><?php echo 'Top Margin:';?></th>
				<td>
			
				<input type="textbox" id="smb_top_margin" name="smb_top_margin" value="<?php echo get_option('smb_top_margin'); ?>" placeholder="10% OR 10px" size="10"/>
                    ( applicable only for left and right float)
				</td>
			</tr>
	    </table>
	</div>
	<!-- Support -->
	<div id="div-smb-support">
	    <h2>Plugin Support</h2>
        <p>Support url  and email goes here....</p>
	</div>
    </div>
	<span class="submit-btn"><?php echo get_submit_button('Save Settings','button-primary','submit','','');?></span>
    <?php settings_fields('smb_sidebar_options'); ?>
	</form>
<!-- End Options Form -->
	</div>
