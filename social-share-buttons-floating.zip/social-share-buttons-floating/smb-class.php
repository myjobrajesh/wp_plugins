<?php
/*
 * Social Share Buttons With Floating Sidebar
 * @get_smb_sidebar_options()
 * @get_smb_sidebar_content()
 * */
?>
<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
// get all options value
	function get_smb_sidebar_options() {
		global $wpdb;
		$ctOptions = $wpdb->get_results("SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'smb_%'");
								
		foreach ($ctOptions as $option) {
			$ctOptions[$option->option_name] =  $option->option_value;
		}

		return $ctOptions;	
	}
/** Get the current url*/
if(!function_exists('smb_current_path_protocol')):
	function smb_current_path_protocol($s, $use_forwarded_host=false)
	{
		$pwahttp = (!empty($s['HTTPS']) && $s['HTTPS'] == 'on') ? true:false;
		$pwasprotocal = strtolower($s['SERVER_PROTOCOL']);
		$pwa_protocol = substr($pwasprotocal, 0, strpos($pwasprotocal, '/')) . (($pwahttp) ? 's' : '');
		$port = $s['SERVER_PORT'];
		$port = ((!$pwahttp && $port=='80') || ($pwahttp && $port=='443')) ? '' : ':'.$port;
		$host = ($use_forwarded_host && isset($s['HTTP_X_FORWARDED_HOST'])) ? $s['HTTP_X_FORWARDED_HOST'] : (isset($s['HTTP_HOST']) ? $s['HTTP_HOST'] : null);
		$host = isset($host) ? $host : $s['SERVER_NAME'] . $port;
		return $pwa_protocol . '://' . $host;
	}
endif;
if(!function_exists('smb_get_current_page_url')):
	function smb_get_current_page_url($s, $use_forwarded_host=false)
	{
		return smb_current_path_protocol($s, $use_forwarded_host) . $s['REQUEST_URI'];
	}
endif;
/* 
 * Site is browsing in mobile or not
 * @smbIsMobile()
 * */
if(!function_exists('smbIsMobile')):
	function smbIsMobile() {
		// Check the server headers to see if they're mobile friendly
		if(isset($_SERVER["HTTP_X_WAP_PROFILE"])) {
			return true;
		}
		// Let's NOT return "mobile" if it's an iPhone, because the iPhone can render normal pages quite well.
		if(isset($_SERVER["HTTP_USER_AGENT"])):
			if(strstr($_SERVER['HTTP_USER_AGENT'], 'iPad')) {
				return false;
			}
		endif;

		// If the http_accept header supports wap then it's a mobile too
		if(isset($_SERVER["HTTP_ACCEPT"])):
			if(preg_match("/wap\.|\.wap/i",$_SERVER["HTTP_ACCEPT"])) {
				return true;
			}
		endif;
		// Still no luck? Let's have a look at the user agent on the browser. If it contains
		// any of the following, it's probably a mobile device. Kappow!
		if(isset($_SERVER["HTTP_USER_AGENT"])){
			$user_agents = array("midp", "j2me", "avantg", "docomo", "novarra", "palmos", "palmsource", "240x320", "opwv", "chtml", "pda", "windows\ ce", "mmp\/", "blackberry", "mib\/", "symbian", "wireless", "nokia", "hand", "mobi", "phone", "cdm", "up\.b", "audio", "SIE\-", "SEC\-", "samsung", "HTC", "mot\-", "mitsu", "sagem", "sony", "alcatel", "lg", "erics", "vx", "NEC", "philips", "mmm", "xx", "panasonic", "sharp", "wap", "sch", "rover", "pocket", "benq", "java", "pt", "pg", "vox", "amoi", "bird", "compal", "kg", "voda", "sany", "kdd", "dbt", "sendo", "sgh", "gradi", "jb", "\d\d\di", "moto");
			foreach($user_agents as $user_string){
				if(preg_match("/".$user_string."/i",$_SERVER["HTTP_USER_AGENT"])) {
					return true;
				}
			}
		}
		// None of the above? Then it's probably not a mobile device.
		return false;
	}
endif;
// Get plugin options
$pluginOptionsVal=get_smb_sidebar_options();
//check plugin in enable or not
if(isset($pluginOptionsVal['smb_active']) && $pluginOptionsVal['smb_active']==1){
	
	if((smbIsMobile()) &&
		isset($pluginOptionsVal['smb_deactive_for_mob']) && $pluginOptionsVal['smb_deactive_for_mob']!='')
	{
	// silent is Gold;
	}
	else
	{
		add_action('wp_footer','get_smb_sidebar_content');
		add_action( 'wp_enqueue_scripts', 'smb_sidebar_scripts' );
		add_action('wp_footer','smb_sidebar_load_inline_js');
		add_action('wp_footer','smb_cookie');
	}
}

function smb_cookie()
{
echo $cookieVal='<script>smbCheckCookie();function smbSetCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname+"="+cvalue+"; "+expires;
}

function smbGetCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(\';\');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==\' \') c = c.substring(1);
        if (c.indexOf(name) != -1) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function smbCheckCookie() {
	var button_status=smbGetCookie("smb_show_hide_status");
    if (button_status != "") {
        
    } else {
        smbSetCookie("smb_show_hide_status", "active",1);
    }
    
}

</script>';
}

//register style and scrip files
function smb_sidebar_scripts() {
	wp_enqueue_script( 'jquery' ); // wordpress jQuery
	wp_register_style( 'smb_sidebar_style', plugins_url( 'css/smb.css',__FILE__ ) );
	wp_enqueue_style( 'smb_sidebar_style' );
}

/*
-----------------------------------------------------------------------------------------------
                              "Add the jQuery code in head section using hooks"
-----------------------------------------------------------------------------------------------
*/


function smb_sidebar_load_inline_js()
{
   $pluginOptionsVal=get_smb_sidebar_options();
	$jscnt='<script>
	  var windWidth=jQuery( window ).width();
	  var animateWidth;
	  var defaultAnimateWidth;';
  $jscnt.='
	jQuery(document).ready(function()
  { 
	animateWidth="55";
    defaultAnimateWidth= animateWidth-10;
	animateHeight="49";
	defaultAnimateHeight= animateHeight-2;';
  
if($pluginOptionsVal['smb_position']=='right' || $pluginOptionsVal['smb_position']=='left'){
 
  $jscnt.='jQuery("div.smbbtns a").hover(function(){
  jQuery(this).animate({width:animateWidth});
  },function(){
    jQuery(this).stop( true, true ).animate({width:defaultAnimateWidth});
  });';
}else
{  
 //silent
  
}


  $jscnt.='jQuery("div.smb-show").hide();
  jQuery("div.smb-show a").click(function(){
    jQuery("div#smb-social-inner").show(500);
     jQuery("div.smb-show").hide(500);
    jQuery("div.smb-hide").show(500);
    smbSetCookie("smb_show_hide_status","active","1");
  });
  
  jQuery("div.smb-hide a").click(function(){
     jQuery("div.smb-show").show(500);
      jQuery("div.smb-hide").hide(500);
     jQuery("div#smb-social-inner").hide(500);
     smbSetCookie("smb_show_hide_status","in_active","1");
  });';
  
   $jscnt.='var button_status=smbGetCookie("smb_show_hide_status");
    if (button_status =="in_active") {
      jQuery("div.smb-show").show();
      jQuery("div.smb-hide").hide();
     jQuery("div#smb-social-inner").hide();
    } else {
      jQuery("div#smb-social-inner").show();
     jQuery("div.smb-show").hide();
    jQuery("div.smb-hide").show();
    }';

  
$jscnt.='});

</script>';
	
	echo $jscnt;
}	
 
/*
-----------------------------------------------------------------------------------------------
                              Display HTML on frontside
-----------------------------------------------------------------------------------------------
*/


function get_smb_sidebar_content() {
	global $post;
	$pluginOptionsVal=get_smb_sidebar_options();

    // Returns the content.

    if(isset($pluginOptionsVal['smb_hide_home'])){
        $hideOnHome=$pluginOptionsVal['smb_hide_home'];
    } else {
        $hideOnHome='';
    }

    if((is_home() && is_front_page()) && $hideOnHome=='yes'):
        echo "";die;
    endif;
    if(is_front_page() && $hideOnHome=='yes' ):
        echo "";die;
    endif;

    /** hide on 404 pages */
    if(is_404()):
		echo "";die;
    endif;

	if(is_category()){
		$category_id = get_query_var('cat');
		$cats = get_the_category();
		$ShareTitle=$cats[0]->name;
	}elseif(is_page() || is_single()){
		$ShareTitle=$post->post_title;
	} elseif(is_archive()){
		global $wp;
		$current_url = get_home_url(null, $wp->request, null);
		if ( is_day() ) :
			$ShareTitle='Daily Archives: '. get_the_date();
		elseif ( is_month() ) :
			$ShareTitle='Monthly Archives: '. get_the_date('F Y');
		elseif ( is_year() ) :
			$ShareTitle='Yearly Archives: '. get_the_date('Y');
		elseif ( is_author() ) :
			$ShareTitle='Author Archives: '. get_the_author();
		else :
			$ShareTitle ='Blog Archives';
		endif;
	} else{
		$ShareTitle=get_bloginfo('name');
	}
	$shareurl = htmlspecialchars(smb_get_current_page_url($_SERVER), ENT_QUOTES, 'UTF-8');
	/* Set title and url for home page */
	if(is_home() || is_front_page()) {
		$shareurl =home_url('/');
		$ShareTitle=get_bloginfo('name');
	}
	$ShareTitle= htmlspecialchars(rawurlencode($ShareTitle));
	/* Get All buttons Image */
	//get facebook button image
	if($pluginOptionsVal['smb_fb_image']!=''){
		$fImg=$pluginOptionsVal['smb_fb_image'];
	} else {
		$fImg=plugins_url( 'images/fb.png', __FILE__ );
	}
	//get twitter button image
	if($pluginOptionsVal['smb_tw_image']!=''){
		$tImg=$pluginOptionsVal['smb_tw_image'];
	} else {
		$tImg=plugins_url( 'images/tw.png', __FILE__ );
	}
	//get Linkedin button image
	if($pluginOptionsVal['smb_li_image']!=''){
		$lImg=$pluginOptionsVal['smb_li_image'];
	} else {
		$lImg=plugins_url( 'images/li.png', __FILE__ );
	}
	/* Get All buttons Image Alt/Title */
	//get facebook button image alt/title
	if($pluginOptionsVal['smb_fb_title']!=''){
		$fImgAlt=$pluginOptionsVal['smb_fb_title'];
	} else {
		$fImgAlt='Share On Facebook';
	}
	//get twitter button image alt/title
	if($pluginOptionsVal['smb_tw_title']!=''){
		$tImgAlt=$pluginOptionsVal['smb_tw_title'];
	} else {
		$tImgAlt='Share On Twitter';
	}
	//get Linkedin button image alt/title
	if($pluginOptionsVal['smb_li_title']!=''){
		$lImgAlt=$pluginOptionsVal['smb_li_title'];
	} else {
		$lImgAlt='Share On Linkedin';
	}

	//get all sizes
	$size['fb'] = ["w"=> 35, "h"=>35];//default
    $size['tw'] = ["w"=> 35, "h"=>35];//default
    $size['li'] = ["w"=> 35, "h"=>35];//default
    if($pluginOptionsVal['smb_fb_size_w']!='') {
        $size['fb']['w'] = $pluginOptionsVal['smb_fb_size_w'];
    }
    if($pluginOptionsVal['smb_tw_size_h']!='') {
        $size['tw']['h'] = $pluginOptionsVal['smb_tw_size_h'];
    }
    if($pluginOptionsVal['smb_li_size_w']!='') {
        $size['li']['w'] = $pluginOptionsVal['smb_li_size_w'];
    }
    if($pluginOptionsVal['smb_li_size_h']!='') {
        $size['li']['h'] = $pluginOptionsVal['smb_li_size_h'];
    }

	if($pluginOptionsVal['smb_li_size_w']!='') {
		$size['li']['w'] = $pluginOptionsVal['smb_li_size_w'];
	}
    if($pluginOptionsVal['smb_li_size_h']!='') {
        $size['li']['h'] = $pluginOptionsVal['smb_li_size_h'];
    }

	// Top Margin
	if($pluginOptionsVal['smb_top_margin']!=''){
		$margin=$pluginOptionsVal['smb_top_margin'];
	} else {
		$margin='25%';
	}

	//Sidebar Position
	if($pluginOptionsVal['smb_position']=='right'){
		$style=' style="top:'.$margin.';right:-5px;"';	$idName=' id="smb-right"'; $showImg='hide-r.png'; $hideImg='show.png';
	} else if($pluginOptionsVal['smb_position']=='bottom'){
		$style=' style="bottom:0;"'; $idName=' id="smb-bottom"'; $showImg='hide-b.png'; $hideImg='show.png';
	} else {
		$idName=' id="smb-left"'; $style=' style="top:'.$margin.';left:0;"'; $showImg='hide-l.png';$hideImg='hide.png';
	}
	/* Get All buttons background color */
	//get facebook button image background color
	if($pluginOptionsVal['smb_fb_bg']!=''){
		$fImgbg=' style="background:'.$pluginOptionsVal['smb_fb_bg'].';"';
	} else {
		$fImgbg='';
	}
	//get twitter button image  background color
	if($pluginOptionsVal['smb_tw_bg']!=''){
		$tImgbg=' style="background:'.$pluginOptionsVal['smb_tw_bg'].';"';
	} else {
		$tImgbg='';
	}
	//get Linkedin button image background color
	if($pluginOptionsVal['smb_li_bg']!=''){
		$lImgbg=' style="background:'.$pluginOptionsVal['smb_li_bg'].';"';
	} else {
		$lImgbg='';
	}

    $sharemsg = "Share this with your friends";

	$floatingSidebarContent='<div id="smb-ddiv"><div class="smb-social-widget" '.$idName.' title="'.$sharemsg.'" '.$style.'>';
	$floatingSidebarContent .= '<div id="smb-social-inner">';

	/** FB */
	if($pluginOptionsVal['smb_fpublishBtn']!=''):
		$floatingSidebarContent .='<div class="smb-sbutton smbbtns"><div id="smb-fb" class="smb-fb"><a href="javascript:" onclick="javascript:window.open(\'//www.facebook.com/sharer/sharer.php?u='.$shareurl.'\', \'\', \'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600\');return false;" target="_blank" title="'.$fImgAlt.'" '.$fImgbg.'>';

		if($fImg!=''){
			$floatingSidebarContent .='<img src="'.$fImg.'" alt="'.$fImgAlt.'" style="width:'.$size['fb']['w'].'px; height='.$size['fb']['h'].'px;"  >';
		}else{
			$floatingSidebarContent .='<i class="smb_facebook"></i>';
		}
		$floatingSidebarContent .='</a></div></div>';
	endif;

	/** TW */
	if($pluginOptionsVal['smb_tpublishBtn']!=''):
		$floatingSidebarContent .='<div class="smb-sbutton smbbtns"><div id="smb-tw" class="smb-tw"><a href="javascript:" onclick="window.open(\'//twitter.com/share?url='.$shareurl.'&text='.$ShareTitle.'\',\'_blank\',\'width=800,height=300\')" title="'.$tImgAlt.'" '.$tImgbg.'>';
		if($tImg!='')
		{
		  $floatingSidebarContent .='<img src="'.$tImg.'" alt="'.$tImgAlt.'"  style="width:'.$size['tw']['w'].'px; height='.$size['tw']['h'].'px;" >';
		}else{
		  $floatingSidebarContent .='<i class="smb_twitter"></i>';
		}
		$floatingSidebarContent .='</a></div></div>';

	endif;

	/**  LI */
	if($pluginOptionsVal['smb_lpublishBtn']!=''):
		$floatingSidebarContent .='<div class="smb-sbutton smbbtns"><div id="smb-li" class="smb-li"><a href="javascript:" onclick="javascript:window.open(\'//www.linkedin.com/cws/share?mini=true&url='. $shareurl.'\',\'\',\'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=800\');return false;" title="'.$lImgAlt.'" '.$lImgbg.'>';
		if($lImg!='')
		{
		  $floatingSidebarContent .='<img src="'.$lImg.'" alt="'.$lImgAlt.'"  style="width:'.$size['li']['w'].'px; height='.$size['li']['h'].'px;" >';
		}else{
		  $floatingSidebarContent .='<i class="smb_linkedin"></i>';
		}
		$floatingSidebarContent .='</a></div></div>';
	endif;

	$floatingSidebarContent .='</div>'; //End social-inner
	$floatingSidebarContent .='</div></div>'; //End social-inner




	print $floatingSidebarContent;
}

/**
 * Add bottons to the end of every post/page.
 *
 * @uses is_home()
 * @uses is_page()
 * @uses is_single()
 */
/*
function smb_the_content_filter( $content ) {

	global $post;

	return $content;

}*/

?>
