<?php
/*
Plugin Name: Social Share Buttons with Floating Sidebar
Plugin URI: http://www.test.com/
Description: It is a simple plugin to add social share buttons with floating display. We can edit share buttons images too.
Author: Rajesh
Author URI: https://rajeshchaudhari.wordpress.com/
Version: 1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
if(!class_exists('Smb_Class'))
{
    class Smb_Class
    {
        /**
         * Construct the plugin object
         */
        public function __construct()
        {
            // register actions
			add_action('admin_init', array(&$this, 'smb_admin_init'));
			add_action('admin_menu', array(&$this, 'smb_sidebar_menu'));
        } // END public function __construct
		
		/**
		 * hook into WP's admin_init action hook
		 */
		public function smb_admin_init()
		{
			// Set up the settings for this plugin
			$this->smb_sidebar_init();
			// Possibly do additional admin_init tasks
		} // END public static function activate
        /**
		 * Initialize some custom settings
		 */     
		public  function smb_sidebar_init()
		{
			// register the settings for this plugin
			register_setting('smb_sidebar_options','smb_active');
			register_setting('smb_sidebar_options','smb_position');
			register_setting('smb_sidebar_options','smb_btn_position');

			register_setting('smb_sidebar_options','smb_fb_image');
			register_setting('smb_sidebar_options','smb_tw_image');
			register_setting('smb_sidebar_options','smb_li_image');

			register_setting('smb_sidebar_options','smb_fb_bg');
			register_setting('smb_sidebar_options','smb_tw_bg');
			register_setting('smb_sidebar_options','smb_li_bg');


			register_setting('smb_sidebar_options','smb_fpublishBtn');
			register_setting('smb_sidebar_options','smb_tpublishBtn');
			register_setting('smb_sidebar_options','smb_lpublishBtn');

			register_setting('smb_sidebar_options','smb_top_margin');
			/** Image Alt */
			register_setting('smb_sidebar_options','smb_fb_title');
			register_setting('smb_sidebar_options','smb_tw_title');
			register_setting('smb_sidebar_options','smb_li_title');

            register_setting('smb_sidebar_options','smb_fb_size_w');
            register_setting('smb_sidebar_options','smb_tw_size_w');
            register_setting('smb_sidebar_options','smb_li_size_w');
            register_setting('smb_sidebar_options','smb_fb_size_h');
            register_setting('smb_sidebar_options','smb_tw_size_h');
            register_setting('smb_sidebar_options','smb_li_size_h');

			register_setting('smb_sidebar_options','smb_hide_home');
			register_setting('smb_sidebar_options','smb_deactive_for_mob');
		} // END public function init_custom_settings()
		/**
		 * add a menu
		 */     
		public function smb_sidebar_menu()
		{
			add_options_page('Social Share Buttons With Floating Sidebar','Social Share Buttons With Floating Sidebar','manage_options',
				'smb-settings',array(&$this,'smb_sidebar_admin_option_page'));

		} // END public function add_menu()

		public function smb_sidebar_admin_option_page()
				{
					if(!current_user_can('manage_options'))
					{
						wp_die(__('You do not have sufficient permissions to access this page.'));
					}

					// Render the settings template
                    include(sprintf("%s/settings.php", dirname(__FILE__)));
					/** 
					 * REGISTER SCRIPT
					 * */
					 wp_enqueue_script('media-upload');
					 wp_enqueue_script('thickbox');
					 wp_register_script('smb-image-upload', plugins_url('/js/smb.js',__FILE__ ), array('jquery','media-upload','thickbox','wp-color-picker'));
					 wp_enqueue_script('smb-image-upload');
					/** 
					 * REGISTER STYLE
					 * */
					wp_register_style( 'smb_admin_style', plugins_url( 'css/admin-smb.css',__FILE__ ) );
					wp_enqueue_style( 'smb_admin_style' );
					wp_enqueue_style( 'wp-color-picker' ); 
					wp_enqueue_style('thickbox');

			 }// END public static function smb_sidebar_admin_option_page
        /**
		 * hook into WP's plugin_action_links_ action hook
		 */
      public static function smb_add_settings_link( $links ) {
            $settings_link = '<a href="options-general.php?page=smb-settings">' . __( 'Settings', 'smb' ) . '</a>';
            array_unshift( $links, $settings_link );
            return $links;
        }
        /**
         * uninstall the plugin
         */
        public function smb_uninstall()
        {
			delete_option('smb_active');
			delete_option('csbbuttons_active');
			delete_option('smb_position');
			delete_option('smb_btn_position');

			delete_option('smb_fb_image');
			delete_option('smb_tw_image');
			delete_option('smb_li_image');

			delete_option('smb_fb_bg');
			delete_option('smb_tw_bg');
			delete_option('smb_li_bg');
			delete_option('smb_fpublishBtn');
			delete_option('smb_tpublishBtn');
			delete_option('smb_lpublishBtn');
			delete_option('smb_top_margin');

			delete_option('smb_fb_title');
			delete_option('smb_tw_title');
			delete_option('smb_li_title');

            delete_option('smb_fb_size_w');
            delete_option('smb_tw_size_w');
            delete_option('smb_li_size_w');
            delete_option('smb_fb_size_h');
            delete_option('smb_tw_size_h');
            delete_option('smb_li_size_h');

			delete_option('smb_deactive_for_mob');

        } // END public static function uninstall
        /**
         * Activate the plugin
         */
        public static function smb_activate()
        {
            // Do nothing
        } // END public static function activate
    
        /**
         * Deactivate the plugin
         */     
        public static function smb_deactivate()
        {
            // Do nothing
        } // END public static function deactivate
		
    } // END class Smb_Class
} // END if(!class_exists('Smb_Class'))

if(class_exists('Smb_Class'))
{
   // Installation and uninstallation hooks
   	register_activation_hook(__FILE__, array('Smb_Class', 'smb_activate'));
   	register_deactivation_hook(__FILE__, array('Smb_Class', 'smb_deactivate'));
   	register_uninstall_hook(__FILE__, array('Smb_Class', 'smb_uninstall'));
    // instantiate the plugin class
    $smb_plugin_template = new Smb_Class();
	// Add a link to the settings page onto the plugin page
	if(isset($smb_plugin_template))
	{
		$plugin = plugin_basename(__FILE__); 
		add_filter("plugin_action_links_$plugin", array('Smb_Class','smb_add_settings_link'));
	    require dirname(__FILE__) . '/smb-class.php';
	}
}
?>
